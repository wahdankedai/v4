<?php 

echo (int) "6";
