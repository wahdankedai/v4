<?php 

require 'boot.php';

session_destroy();

exit;