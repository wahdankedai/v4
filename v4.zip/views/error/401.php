<?php 
header("HTTP/1.0 401 Unauthorized");

echo "Gak boleh layaw";