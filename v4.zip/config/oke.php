<?php return array (
  'triwulan1' => false,
  'aku' => 'sfhgsdfsdhfs',
  'koew' => 
  array (
    0 => 'aku',
    1 => 'kowe',
  ),
);