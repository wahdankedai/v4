<?php 

return [
    'host' => 'localhost',
    'name' => 'forge',
    'user' => 'root',
    'pass' => '',
];