<?php 

return [
    'name' => 'E-Moneva',
    'client' => 'Kabupaten Banyuwangi',
];