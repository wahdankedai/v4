<?php 

if (false) {
    echo "sip";
}