function deleteUnnecesaryDiv () {
	var d = document.getElementsByClassName('')
}

idleTimer = null;
idleState = false;
idleWait = 5 * 60 * 1000; // 5 menit non aktif = logout

(function ($) {

    $(document).ready(function () {
    
        $('*').bind('mousemove keydown scroll', function () {
        
            clearTimeout(idleTimer);
                    
            if (idleState == true) {             
            }
            
            idleState = false;
            
            idleTimer = setTimeout(function () { 
                
                $.post("logout.php").done(function() {
                   window.location.reload();
                });

                idleState = true; }, idleWait);
        });
        
        $("body").trigger("mousemove");
    
    });
}) (jQuery)

$(document).ready(function(){

	$('#logout').click(function(e) {
		e.preventDefault();

		$.messager.confirm('Log Out', 'Apakah Anda yakin untuk Keluar?', function(r){
			if (r){
				window.location.replace("logout.php");
			}
		});
	});


	$('#menu-manager').click(function(e) {
		e.preventDefault();

		$.post("view/administrator/menu-manager.php",
		function (data) {
			$("#x-content").empty();
			if (data == "404")
			{
				window.location.replace("logout");
			} 
			else 
			{
				$("#x-content").append(data);
			}
		});

	});

	$('#user-manager').click(function(e) {
		e.preventDefault();

		$.post("view/administrator/user-manager.php",
		function (data) {
			$("#x-content").empty();
			if (data == "404")
			{
				window.location.replace("logout");
			} 
			else 
			{
				$("#x-content").append(data);
			}
		});

	});

	

});
