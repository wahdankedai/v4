<?php 

require '../../boot.php';
require '../../session.php';

var_dump($session);

exit;