<?php 

require '../boot.php';

echo json_encode(Config::get('evaluasi'));


exit;